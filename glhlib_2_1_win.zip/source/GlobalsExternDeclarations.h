#ifndef _GLOBALSEXTERNDECLARATIONS_H_
#define _GLOBALSEXTERNDECLARATIONS_H_





extern sreal	*FArray128;								//Reserved 128 sreal for SSE calculations
extern sint	MemoryAlignmentOnAllocation;				//Default : 16. For SSE (memory align)





#endif		//_GLOBALSEXTERNDECLARATIONS_H_

